from setuptools import find_packages, setup

setup(
    # name = "airtag-bat",
    # version = "1.0.0",
    # description = "A tool to read AirTag battery status",
    # author = "Henrik zu Jeddeloh",
    # author_email = "henrik.zujeddeloh@protonmail.com",
    # url = "https://github.com/henrikzujeddeloh/AirTagBattery" ,
    # packages = find_packages(),
    # install_requires = ["tabulate"],
    # entry_points={
    #     'console_scripts': 'airtag-bat=airtag-bat:get_bat',
    # },
)
